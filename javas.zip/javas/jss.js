let userBox = document.querySelector('.header .flex .account-box');

document.querySelector('#user-btn').onclick = () =>{
    userBox.classList.toggle('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.header .flex .navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    userBox.classList.remove('active');
}

window.onscroll = () =>{
    userBox.classList.remove('active');
    navbar.classList.remove('active');
}
document.addEventListener('DOMContentLoaded', function () {
    var elem = document.documentElement; // Get the root element (html)
    var requestFullscreen = elem.requestFullscreen || elem.webkitRequestFullscreen || elem.mozRequestFullScreen || elem.msRequestFullscreen;

    // Check if the requestFullscreen method is supported
    if (requestFullscreen) {
        // Function to request fullscreen mode
        function enterFullscreen() {
            if (!document.fullscreenElement) {
                requestFullscreen.call(elem);
            }
        }

        // Call the function to enter fullscreen mode
        enterFullscreen();

        // Event listener to re-enter fullscreen if user exits it
        document.addEventListener('fullscreenchange', function () {
            if (!document.fullscreenElement) {
                enterFullscreen();
            }
        });
    }
});
  // Get all star elements
  document.addEventListener('DOMContentLoaded', function() {
    const ratingsContainers = document.querySelectorAll('.rating');
  
    ratingsContainers.forEach(function(ratingsContainer) {
      const stars = ratingsContainer.querySelectorAll('.star');
  
      stars.forEach(function(star) {
        star.addEventListener('click', function() {
          const rating = parseInt(star.getAttribute('data-value'));
          const messageID = ratingsContainer.getAttribute('data-message-id');
  
          // Update the UI to reflect the selected rating
          stars.forEach(s => s.classList.remove('selected'));
          for (let i = 0; i < rating; i++) {
            stars[i].classList.add('selected');
          }
  
          // Send the rating to the server
          sendRatingToServer(messageID, rating);
        });
      });
    });
  
    function sendRatingToServer(messageID, rating) {
      // AJAX request to send rating to the server
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'http://localhost:8080/phpmyadmin/index.php?route=/sql&pos=0&db=shop_db&table=message', true); // Adjust the URL to your server endpoint
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
          if (xhr.status === 200) {
            console.log('Rating saved successfully');
          } else {
            console.error('Failed to save rating');
          }
        }
      };
      xhr.send(JSON.stringify({ messageID: messageID, rating: rating }));
    }
  });
// Select the box element
// Wait for the DOM to fully load

// Select all .box elements
const boxes = document.querySelectorAll('.box');

// Loop through each .box element
boxes.forEach(box => {
  // Add mouseover event listener
  box.addEventListener('mouseover', function() {
    this.classList.add('zoom-out'); // Add zoom-out class on mouseover
  });

  // Add mouseout event listener
  box.addEventListener('mouseout', function() {
    this.classList.remove('zoom-out'); // Remove zoom-out class on mouseout
  });
});

const dropdowns=document.querySelectorAll('.dropdown');

dropdowns.forEach(dropdown => {

  const select=dropdown.querySelector('.select');
  const caret=dropdown.querySelector('.caret');
  const menu=dropdown.querySelector('.menu');
  const options=dropdown.querySelectorAll('.menu li');
  const selected=dropdown.querySelector('.selected');

  select.addEventListener('click', () => {

    select.classList.toggle('select-clicked');
    select.classList.toggle('caret-rotate');
    menu.classList.toggle('menu-open');
});
  options.forEach(option => {

    options.addEventListener('click',() => {

      selected.innerText=option.innerText;

      select.classList.remove('select-clicked');
      caret.classList.remove('caret-rotate');
      menu.classList.remove('menu-open');

     
   
    });
  });

});
