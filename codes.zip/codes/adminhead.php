<?php
// Start session
session_start();

// Check if $_SESSION['admin_name'] and $_SESSION['admin_email'] are set before accessing them
$user_name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : '';
$user_email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : '';
?>

<header class="header">
   <div class="flex">
      <a href="adminp.php" class="logo"><span>
         سەرپەرشتیار</span></a>
      <nav class="navbar">
         <a href="adminp.php">پەرەی سەرەکی</a>
         <a href="adminpro.php">بەرهەمەکان</a>
         <a href="adminord.php">داواکراوەکان</a>
         <a href="adminuse.php">بەکارهێنەرەکان</a>
         <a href="admincon.php">نامەکان</a>
      </nav>
      <div class="icons">
         <div id="menu-btn" class="fas fa-bars"></div>
         <div id="user-btn" class="fas fa-user"></div>
      </div>
      <div class="account-box">
         <p><span><?php echo $user_name; ?></span>:ناوی بەکارهێنەر </p>
         <p><span><?php echo $user_email; ?></span> :ئیمەیڵ<</p>
         <a href="logo.php" class="delete-btn">دەرچوون</a>
         <div>نوێ <a href="logn.php">چونه‌ ژووره‌وه</a> | <a href="reg.php">خۆ تۆمارکردن</a> </div>
      </div>
   </div>
</header>
