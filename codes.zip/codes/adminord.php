<?php

@include 'conft.php';

session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])){
   header('location:logn.php');
   exit(); // Stop further execution
}

// Get the logged-in user ID
$user_id = $_SESSION['user_id'];

// Check if the logged-in user has user ID 18 or 19
$query = "SELECT id FROM users WHERE id = '$user_id' AND id IN (18, 19)";
$result = mysqli_query($conn, $query);

// Check if the query returned any rows
if(mysqli_num_rows($result) != 1){
   header('location:logn.php'); // Redirect to login page or another unauthorized page
   exit(); // Stop further execution
}

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>dashboard</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/adminstyle.css">

</head>
<body>
   
<?php @include 'adminhead.php'; ?>

<section class="placed-orders">


<section class="title">
    <p><span>شوێنی داواکردن</span></p>
</section>
 
    
 
   <div class="box-container">

      <?php
      
      $select_orders = mysqli_query($conn, "SELECT * FROM `orders`") or die('query failed');
      if(mysqli_num_rows($select_orders) > 0){
         while($fetch_orders = mysqli_fetch_assoc($select_orders)){
      ?>
      <div class="box">
         <p> <span><?php echo $fetch_orders['user_id']; ?></span> :ناونیشانی بەکارهێنەر </p>
         <p> <span><?php echo $fetch_orders['placed_on']; ?></span> :دانراوە لەسەر  </p>
         <p> <span><?php echo $fetch_orders['name']; ?></span> :ناو  </p>
         <p> <span><?php echo $fetch_orders['number']; ?></span> :ژمارە</p>
         <p> <span><?php echo $fetch_orders['email']; ?></span> :ئیمەیڵ  </p>
         <p><span><?php echo $fetch_orders['address']; ?></span> :ناونیشان  </p>
         <p><span><?php echo $fetch_orders['total_products']; ?></span> :کۆی گشتی بەرهەمەکان  </p>
         <p> <span><?php echo $fetch_orders['total_price']; ?>,000IQD</span>:نرخی گشتی  </p>
         <p><span><?php echo $fetch_orders['method']; ?></span> :شێوازی پارەدان  </p>
         <form action="" method="post">
            <input type="hidden" name="order_id" value="<?php echo $fetch_orders['id']; ?>">
            <select name="update_payment">
               <option disabled selected ><?php echo $fetch_orders['payment_status']; ?></option>
               <option value="pending" class="title">هەڵپەسێردراو</option>
               <option value="completed" class="title">تەواو بووە</option>
            </select>
            <input type="submit" name="update_order" value="نوێکردنەوە" class="option-btn">
            <a href="adminord.php?delete=<?php echo $fetch_orders['id']; ?>" class="delete-btn" onclick="return confirm('delete this order?');">سڕینەوە</a>
         </form>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">تا ئێستا هیچ داواکارییەک نەکراوە!</p>';
      }
      ?>
   </div>

</section>













<script src="javas/adminjs.js"></script>

</body>
</html>