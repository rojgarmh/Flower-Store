<?php

@include 'conft.php';

session_start();


$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;

// Check if an action is performed and user is not logged in
$message = array(); // Initialize $message as an array

if (isset($_POST['add_to_wishlist'])) {
    // Check if user is logged in
    if (!$user_id) {
        // If not logged in, prompt user to login
        $message[] = 'تکایە خۆت تۆمار بکە  ';
    } else {
// If logged in, proceed with adding item to wishlist
        $product_id = $_POST['product_id'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_image = $_POST['product_image'];

        $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

        $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

        if (mysqli_num_rows($check_wishlist_numbers) > 0) {
            $message[] = 'پێشتر زیاد کراوە';
        } elseif (mysqli_num_rows($check_cart_numbers) > 0) {
            $message[] = 'پێشتر زیاد کراوە';
        } else {
            mysqli_query($conn, "INSERT INTO `wishlist`(user_id, pid, name, price, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_image')") or die('query failed');
            $message[] = 'بە سەرکەوتوویی زیاد کرا';
        }
    }
}

if (isset($_POST['add_to_cart'])) {
    // Check if user is logged in
    if (!$user_id) {
        // If not logged in, prompt user to login
        $message[] = 'تکایە خۆت تۆمار بکە ';
    } else {
        // If logged in, proceed with adding item to cart
        $product_id = $_POST['product_id'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_image = $_POST['product_image'];
        $product_quantity = $_POST['product_quantity'];

        $check_cart_numbers = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

        if (mysqli_num_rows($check_cart_numbers) > 0) {
            $message[] = 'پێشتر زیاد کراوە';
        } else {

            $check_wishlist_numbers = mysqli_query($conn, "SELECT * FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');

            if (mysqli_num_rows($check_wishlist_numbers) > 0) {
                mysqli_query($conn, "DELETE FROM `wishlist` WHERE name = '$product_name' AND user_id = '$user_id'") or die('query failed');
            }

            mysqli_query($conn, "INSERT INTO `cart`(user_id, pid, name, price, quantity, image) VALUES('$user_id', '$product_id', '$product_name', '$product_price', '$product_quantity', '$product_image')") or die('query failed');
            $message[] = 'بە سەرکەوتووی زیاد کرا ';
        }
    }
}

// Output the messages

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/css1.css">

</head>
<body>
   
<?php @include 'head.php'; ?>

<section class="quick-view">


<section class="title">
    <p><span> وردەکارییەکانی بەرهەم </span></p>
</section>

    <?php 
     include 'conft.php'; 
        if(isset($_GET['pid'])){
            $pid = $_GET['pid'];
            $select_plant = mysqli_query($conn, "SELECT * FROM `plant` WHERE id = '$pid'") or die('query failed');
         if(mysqli_num_rows($select_plant) > 0){
            while($fetch_plant= mysqli_fetch_assoc($select_plant)){
    ?>
    
    <form action="" method="POST">
         <img src="uploaded_img/<?php echo $fetch_plant['image']; ?>" alt="" class="image">
         <div class="name"><b><?php echo $fetch_plant['name']; ?></b></div>
         <div class="price"><span><?php echo $fetch_plant['price']; ?>,000IQD</span></div>
      
         <div class="details"><?php echo $fetch_plant['details']; ?></div>
         <input type="number" name="product_quantity" value="1" min="0" class="qty">
         <input type="hidden" name="product_id" value="<?php echo $fetch_plant['id']; ?>">
         <input type="hidden" name="product_name" value="<?php echo $fetch_plant['name']; ?>">
         <input type="hidden" name="product_price" value="<?php echo $fetch_plant['price']; ?>">
         <input type="hidden" name="product_image" value="<?php echo $fetch_plant['image']; ?>">
         <input type="submit" value="زیاد کردن بۆ سەبەتە" name="add_to_cart" class="btn">
      </form>
           
    <?php
            }
        }else{
        echo '<p class="empty">هیچ وردەکارییەکی بەرهەمەکان لەبەردەستدا نییە</p>';
        }
    }
    ?>

    <div class="more-btn">
        <a href="hom.php" class="option-btn">بڕۆ بۆ لاپەڕەی سەرەکی</a>
    </div>

</section>


<script src="javas/jss.js"></script>

</body>
</html>