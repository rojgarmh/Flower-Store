<?php

@include 'conft.php';
$query = "SELECT * FROM plant where p_status='1' order by id desc";
$r=mysqli_query($conn,$query);
?>