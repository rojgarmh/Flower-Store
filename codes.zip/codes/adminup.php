<?php

@include 'conft.php';

session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('location: logn.php');
    exit(); // Stop further execution
}

// Get the logged-in user ID
$user_id = $_SESSION['user_id'];

// Check if the logged-in user has user ID 18 or 19
$query = "SELECT id FROM users WHERE id = '$user_id' AND id IN (18, 19)";
$result = mysqli_query($conn, $query);

// Check if the query returned any rows
if (mysqli_num_rows($result) != 1) {
    header('location: logn.php'); // Redirect to the login page or another unauthorized page
    exit(); // Stop further execution
}

// Proceed with other actions only if the logged-in user has the appropriate user ID

// Process form submission for updating product
if (isset($_POST['update_product'])) {
    $update_p_id = $_POST['update_p_id'];
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $details = mysqli_real_escape_string($conn, $_POST['details']);

    // Update product details in the database
    mysqli_query($conn, "UPDATE `plant` SET name = '$name', details = '$details', price = '$price' WHERE id = '$update_p_id'") or die('Query failed');

    // Handle image upload
    if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = $_FILES['image']['name'];
        $image_tmp_name = $_FILES['image']['tmp_name'];
        $image_folder = 'uploaded_img/' . $image;

        // Move uploaded image to the desired location
        move_uploaded_file($image_tmp_name, $image_folder);
        
        // Update image field in the database
        mysqli_query($conn, "UPDATE `plant` SET image = '$image' WHERE id = '$update_p_id'") or die('Query failed');
    }

    // Redirect to the appropriate page after successful update
    header('location: adminpro.php');
    exit(); // Stop further execution
}

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>نوێکردنەوەی بەرهەم</title>

   <!-- Font Awesome CDN link -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- Custom admin CSS file link -->
   <link rel="stylesheet" href="style/adminstyle.css">

</head>
<body>
   
<?php @include 'adminhead.php'; ?>

<section class="update-product">

<?php

$update_id = isset($_GET['update']) ? $_GET['update'] : null;
if ($update_id === null) {
    echo '<p class="empty">هیچ بەرهەمێک هەڵنەبژێردراوە</p>';
} else {
    $select_product_query = "SELECT * FROM `plant` WHERE id = '$update_id'";
    $select_product_result = mysqli_query($conn, $select_product_query);

    if (mysqli_num_rows($select_product_result) > 0) {
        $fetch_product = mysqli_fetch_assoc($select_product_result);
?>

<form action="" method="post" enctype="multipart/form-data">
   <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" class="image"  alt="">
   <input type="hidden" value="<?php echo $fetch_product['id']; ?>" name="update_p_id">
   <input type="text" class="box" value="<?php echo $fetch_product['name']; ?>" required placeholder="نوێکردنەوەی ناوی بەرهەم" name="name">
   <input type="number" min="0" class="box" value="<?php echo $fetch_product['price']; ?>" required placeholder="نوێکردنەوەی نرخ" name="price">
   <textarea name="details" class="box" required placeholder="update product details" cols="30" rows="10"><?php echo $fetch_product['details']; ?></textarea>
   <input type="file" accept="image/jpg, image/jpeg, image/png" class="box" name="image">
   <input type="submit" value="نوێکردنەوە" name="update_product" class="btn">
   <a href="adminpro.php" class="option-btn">بگەڕێوە دواوە</a>
</form>

<?php
    } else {
        echo '<p class="empty">هیچ بەرهەمێک هەڵنەبژێردراوە</p>';
    }
}
?>

</section>


<script src="javas/adminjs.js"></script>

</body>
</html>
