<?php

@include 'conft.php';

session_start();

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>dashboard</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/css1.css">

</head>
<body>
   
<?php @include 'head.php'; ?>

<section class="placed-orders">

   <h1 class="title">شوێنی داواکاریەکان</h1>

   <div class="box-container">

      <?php
      
      $select_orders = mysqli_query($conn, "SELECT * FROM `orders`") or die('query failed');
      if(mysqli_num_rows($select_orders) > 0){
         while($fetch_orders = mysqli_fetch_assoc($select_orders)){
      ?>
      <div class="box">
         <p>:<span><?php echo $fetch_orders['user_id']; ?></span> :ناونیشانی بەکارهێنەر </p>
         <p>  <span><?php echo $fetch_orders['placed_on']; ?></span> </p>
         <p>:ناو <span><?php echo $fetch_orders['name']; ?></span> </p>
         <p>:ژمارە <span><?php echo $fetch_orders['number']; ?></span> </p>
         <p>:ئیمەیڵ <span><?php echo $fetch_orders['email']; ?></span> </p>
         <p>:ناونیشان <span><?php echo $fetch_orders['address']; ?></span> </p>
         <p>:کۆی گشتی بەرهەمەکان <span><?php echo $fetch_orders['total_products']; ?></span> </p>
         <p>:نرخی گشتی <span>$<?php echo $fetch_orders['total_price']; ?>/-</span> </p>
         <p>:شێوازی پارەدان <span><?php echo $fetch_orders['method']; ?></span> </p>
         <form action="" method="post">
            <input type="hidden" name="order_id" value="<?php echo $fetch_orders['id']; ?>">
            <select name="update_payment">
               <option disabled selected><?php echo $fetch_orders['payment_status']; ?></option>
               <option value="pending">هەڵپەسێردراو</option>
               <option value="completed">تەواو بووە</option>
            </select>
            <input type="submit" name="update_order" value="update" class="option-btn">
            <a href="adminord.php?delete=<?php echo $fetch_orders['id']; ?>" class="delete-btn" onclick="return confirm('delete this order?');">سڕینەوە</a>
         </form>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">no orders placed yet!</p>';
      }
      ?>
   </div>

</section>


<script src="js/jss.js"></script>

</body>
</html>