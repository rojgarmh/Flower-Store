<head>
   <!-- Other meta tags and stylesheets -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
   <style>
       .price-range-bar {
           height: 5px;
           background-color: #007bff; /* Set the color of the bar */
           position: relative;
           margin-top: 10px;
       }

       .price-range-bar-fill {
           height: 100%;
           background-color: #ff8800; /* Set the color of the filled portion of the bar */
           position: absolute;
           top: 0;
           left: 0;
       }
   </style>
</head>
<body>
   <!-- Existing HTML content -->
   <div class="price-range-block">
       <div id="slider-range" class="price-filter-range" name="rangeInput"></div>
       <div class="price-range-bar">
           <div id="price-range-fill" class="price-range-bar-fill"></div>
       </div>
       <div style="margin:30px auto">
           <input type="number" min=0 max="9900" oninput="validity.valid||(value='0');" id="min_price" class="price-range-field" />
           <input type="number" min=0 max="10000" oninput="validity.valid||(value='10000');" id="max_price" class="price-range-field" />
       </div>
       <button class="price-range-search" id="price-range-submit">Search</button>
       <div id="searchResults" class="search-results-block"></div>
   </div>

   <!-- Include jQuery and jQuery UI libraries -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
   <script>
       $(document).ready(function() {
           // Initialize price range slider
           $("#slider-range").slider({
               range: true,
               min: 0,
               max: 10000,
               values: [0, 10000],
               slide: function(event, ui) {
                   $("#min_price").val(ui.values[0]);
                   $("#max_price").val(ui.values[1]);
                   updatePriceRangeBar(ui.values[0], ui.values[1]);
               }
           });

           // Update slider values based on user input
           $("#min_price").on("input", function() {
               var min = $(this).val();
               var max = $("#max_price").val();
               $("#slider-range").slider("values", 0, min);
               updatePriceRangeBar(min, max);
           });

           $("#max_price").on("input", function() {
               var min = $("#min_price").val();
               var max = $(this).val();
               $("#slider-range").slider("values", 1, max);
               updatePriceRangeBar(min, max);
           });

           // Function to update the price range bar
           function updatePriceRangeBar(min, max) {
               var range = max - min;
               var totalRange = 10000; // Maximum range value
               var fillPercentage = (range / totalRange) * 100;
               $("#price-range-fill").css("width", fillPercentage + "%");
           }
       });
   </script>
</body>
