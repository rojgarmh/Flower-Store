<?php

@include 'conft.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:logn.php');
};

if(isset($_POST['send'])){

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    $msg = mysqli_real_escape_string($conn, $_POST['message']);
    


    $select_message = mysqli_query($conn, "SELECT * FROM `message` WHERE name = '$name' AND email = '$email'  AND message = '$msg'") or die('query failed');

    if(mysqli_num_rows($select_message) > 0){
        $message[] = ' !پێشتر پەیام نێردراوە ';
    }else{
        mysqli_query($conn, "INSERT INTO `message`(user_id, name, email, message) VALUES('$user_id', '$name', '$email', '$msg')") or die('query failed');
        $message[] = '!پەیامەکە بە سەرکەوتووی نێردرا';
    }

}

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>پەیوەندییەکان</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/css1.css">

</head>
<body>
   
<?php @include 'head.php'; ?>



<section class="title">
    <p><span>پەیوەندیمان پێوەبکە </span></p>
</section>
 
    



<section class="home-contact">

   <div class="content">
   <section class="contact" id="contact">
<form action="" method="POST">
    <input type="text" name="name" placeholder="ناوی خۆت تۆمار بکە" class="box" required> 
    <input type="email" name="email" placeholder="ئیمەیڵەکەت داخڵ بکە" class="box" required>
    <textarea name="message" class="box" placeholder="نامەکەت بنووسە" required cols="90" rows="70" style="width: 350px;text-align:right"></textarea>
  
    
    <input type="submit" value="ناردن" name="send" class="btn">
</form>

</section>

   </div>

</section>



<?php @include 'foot.php'; ?>


<script src="javas/jss.js"></script>

</body>
</html>