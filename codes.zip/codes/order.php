<?php

@include 'conft.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:logn.php');
}

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>orders</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/css1.css">

</head>
<body>
<?php @include 'head.php'; ?>
   


<section class="title">
    <p><span>داواکارییەکان</span></p>
</section>
 
    

<section class="placed-orders">



    <div class="box-container">

    <?php
        $select_orders = mysqli_query($conn, "SELECT * FROM `orders` WHERE user_id = '$user_id'") or die('query failed');
        if(mysqli_num_rows($select_orders) > 0){
            while($fetch_orders = mysqli_fetch_assoc($select_orders)){
    ?>
    <div class="box">
        <p>  <span><?php echo $fetch_orders['placed_on']; ?></span>  :شوێنی داواکردن</p>
        <p>  <span><?php echo $fetch_orders['name']; ?></span>  :ناوی بەکارهێنەر </p>
        <p><span><?php echo $fetch_orders['number']; ?></span>  :ژمارەی بەکارهێنەر</p>
        <p>  <span><?php echo $fetch_orders['email']; ?></span> :ئیمەیڵ </p>
        <p>  <span><?php echo $fetch_orders['address']; ?></span> :ناونیشان  </p>
        <p> <span><?php echo $fetch_orders['method']; ?></span>  :جۆری پارەدان  </p>
        <p>داواکارییەکانت :<span><?php echo $fetch_orders['total_products'];?></span> </p>
        <p>  <span><?php echo $fetch_orders['total_price']; ?>,000IQD</span> :کۆی گشتی</p>
        <p> <span style="color:<?php if($fetch_orders['payment_status'] == 'pending'){echo 'tomato'; }else{echo 'green';} ?>"><?php echo $fetch_orders['payment_status']; ?></span> :بارودۆخی داواکاری </p>
    </div>
    <?php
        }
    }else{
        echo '<p class="empty"> !هیچ داواکارییەک بەردەست نییە </p>';
    }
    ?>
    </div>

</section>


<?php @include 'foot.php'; ?>

<script src="javas/jss.js"></script>

</body>
</html>