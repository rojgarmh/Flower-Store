<?php
@include 'conft.php';

session_start();

$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$sql = "SELECT * FROM message";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>دەربارەى</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/css1.css">

</head>
<body >
   
<?php @include 'head.php'; ?>
<br><br><br><br><br><br><br>
<section class="title" >
    <p><span>دەربارەی ئێمە</span><p>
   
</section>

<section class="about">
<div class="box-container">
    <div class="flex">

        <div class="image">
            <img src="uploaded_img/img1.jpg" alt="">
        </div>

        <div class="content">
        <p id="q">ئەوەی ئێمە دابینی دەکەین؟  </p>
        <p>"ماڵپەڕی گوڵەکانمان وەک پلاتفۆرمێک کاردەکات کە تایبەتە بە دابینکردنی کۆمەڵێک ڕێکخستنی گوڵ بە کڕیاران، کە خزمەت بە بۆنە و ئارەزووە جیاوازەکان دەکات. بە جەختکردنەوەیەکی زۆر لەسەر کوالیتی، تازەیی، و سەرنجڕاکێشیی گوڵەکان 
جگە لەوەش ماڵپەڕەکەمان ڕووکارێکی بەکارهێنەر دۆستانە پێشکەش دەکات، کە ئاسانکاری دەکات بۆ گەڕانێکی بێ کێشە و هەڵبژاردنی بێ ماندووبوون لە بەرهەمە گوڵییەکان. لە ڕێگەی بژاردەی پارەدانی پارێزراو و خزمەتگوزاری گەیاندنی کارامە ئامانجمان متمانەی ئێوەیە.</p>
            <a href="bazar.php" class="btn">ئێستا بازاڕی بکە</a>
        </div>

    </div>
</div>

<div class="box-contain">
    <div class="flex">

    <div class="image">
            <img src="uploaded_img/img2.jpg" alt="">
        </div>
        
        <div class="content">
        <p id="q"> بۆ ئێمەت هەڵبژارد؟ </p>  
        <p>.لەگەڵ ئێمە فیدباکەکانتان یارمەتیدەرمان دەبن بۆ بەرزکردنەوەی ماڵپەڕەکەمان و ئەزموونێکی باشتر لە بازاڕکردنتان بۆ دابین دەکات سوپاس بۆ پشتگیریتان و بۆ یارمەتیدانتان بۆ گەشەکردن.</p>
            <a href="contc.php" class="btn">پەیوەندیمان پێوە بکە</a>
        </div>

       

    </div>
</div>
<div class="box-container">
    <div class="flex">

    <div class="image">
            <img src="uploaded_img/img3.jpg" alt="">
        </div>

        <div class="content">
            <p id="q"> ڕا و بۆچوونی کڕیاران چین ؟ </p>
            <p>فیدباکی کڕیاران وەک سەکۆیەکە بۆ ئاڵوگۆڕکردنی فیدباکەکان لەنێوان کڕیاران کە ئەوەش بازرگانان بەهێز  دەکات ئاگادار بن لە بڕیاردان </p>
            <a href="#reviews" class="btn">پێداچوونەوەکانی کڕیاران</a>
        </div>
       
    </div>
</div>
</section>

<br><br>
<section class="title">
    <p><span>ڕا و بۆچوونی کڕیاران</span><p>
   
</section>

<section class="reviews" id="reviews">
    <div class="box-container">
        <div class="message-form">
            <?php
            if ($result !== false && $result->num_rows > 0) {
                while ($fetch_message = $result->fetch_assoc()) {
            ?>
            <div class="message-box">
                <p class="message"><?php echo $fetch_message['message']; ?></p>
                <h3 class="name"><?php echo $fetch_message['name']; ?></h3>
            </div>
            <?php
                }
            } else {
                echo "<p>No messages found</p>";
            }
            ?>
        </div>
    </div>
</section>














<script src="javas/jss.js"></script>

</body>
</html>