<?php

@include 'conft.php';

session_start();


// Check if user is logged in
if(!isset($_SESSION['user_id'])){
   header('location:logn.php');
   exit(); // Stop further execution
}

// Get the logged-in user ID
$user_id = $_SESSION['user_id'];

// Check if the logged-in user has user ID 18 or 19
$query = "SELECT id FROM users WHERE id = '$user_id' AND id IN (18, 19)";
$result = mysqli_query($conn, $query);

// Check if the query returned any rows
if(mysqli_num_rows($result) != 1){
   header('location:logn.php'); // Redirect to login page or another unauthorized page
   exit(); // Stop further execution
}

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `message` WHERE id = '$delete_id'") or die('query failed');
   header('location:admincon.php');
}

?>

<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/adminstyle.css">

</head>
<body>
   
<?php @include 'adminhead.php'; ?>

<section class="messages">

<section class="title">
    <p><span>نامە</span></p>
</section>
 
    
   

   <div class="box-container">

      <?php
       $select_message = mysqli_query($conn, "SELECT * FROM `message`") or die('query failed');
       if(mysqli_num_rows($select_message) > 0){
          while($fetch_message = mysqli_fetch_assoc($select_message)){
      ?>
      <div class="box">
         <p> <span><?php echo $fetch_message['user_id']; ?></span> :ناونیشانی بەکارهێنەر </p>
         <p> <span><?php echo $fetch_message['name']; ?></span> :ناوی بەکارهێنەر</p>
         <p> <span><?php echo $fetch_message['email']; ?></span>  :ئیمەیڵ</p>
         <p> <span><?php echo $fetch_message['message']; ?></span> :نامە </p>
         <a href="admincon.php?delete=<?php echo $fetch_message['id']; ?>" onclick="return confirm('دڵنیایی لە سڕینەوە؟');" class="delete-btn">سڕینەوە</a>
      </div>
      <?php
         }
      }else{
         echo '<p class="empty">!هیچ نامەیەک بوونی نییە</p>';
      }
      ?>
   </div>

</section>













<script src="javas/adminjs.js"></script>

</body>
</html>