<?php

@include 'conft.php';

session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])){
   header('location:logn.php');
   exit(); // Stop further execution
}

// Get the logged-in user ID
$user_id = $_SESSION['user_id'];

// Check if the logged-in user has user ID 18 or 19
$query = "SELECT id FROM users WHERE id = '$user_id' AND id IN (18, 19)";
$result = mysqli_query($conn, $query);

// Check if the query returned any rows
if(mysqli_num_rows($result) != 1){
   header('location:logn.php'); // Redirect to login page or another unauthorized page
   exit(); // Stop further execution
}

// Proceed with other actions only if the logged-in user has the appropriate user ID

if(isset($_GET['delete'])){
   $delete_id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM `users` WHERE id = '$delete_id'") or die('query failed');
   header('location:adminuse.php');
   exit(); // Stop further execution
}

?>


<!DOCTYPE html>
<html lang="ku">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>dashboard</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="style/adminstyle.css">

</head>
<body>
   
<?php @include 'adminhead.php'; ?>

<section class="users">

<section class="dashboard">
<section class="title">
    <p><span> ئەکاونتی بەکارهێنەران </span></p>
</section>
   

   <div class="box-container">
      <?php
         $select_users = mysqli_query($conn, "SELECT * FROM `users`") or die('query failed');
         if(mysqli_num_rows($select_users) > 0){
            while($fetch_users = mysqli_fetch_assoc($select_users)){
      ?>
      <div class="box">
         <p><span><?php echo $fetch_users['id']; ?></span> :ناونیشانی بەکارهێنەر </p>
         <p><span><?php echo $fetch_users['name']; ?></span> :ناوی بەکارهێنەر </p>
         <p><span><?php echo $fetch_users['email']; ?></span> :ئیمەیڵ </p>
         <p><span style="color:<?php if($fetch_users['user_type'] == 'admin'){ echo 'var(--orange)'; }; ?>"><?php echo $fetch_users['user_type']; ?></span>:جۆری بەکارهێنەر </p>
         <a href="adminuse.php?delete=<?php echo $fetch_users['id']; ?>" onclick="return confirm('delete this user?');" class="delete-btn">سڕینەوە</a>
      </div>
      <?php
         }
      }
      ?>
   </div>

</section>

<script src="javas/adminjs.js"></script>

</body>
</html>