<section class="footer">

    <div class="box-container">

        <div class="box">
            <p ><b>بەستەرە خێراکان </b></p>
            <a href="hom.php">سەرەکی</a>
            <a href="abot.php">دەربارەی ئێمە</a>
            <a href="contc.php">پەیوەندی</a>
         
            <a href="bazar.php">بازاڕ</a>
        </div>

        <div class="box">
            <p  ><b>بەستەری زیاتر  </b></p> 
            <a href="logn.php"> چوونەژوورەوە</a>
            <a href="reg.php">خۆتۆمار کردن </a>
            <a href="order.php">داواکارییەکان</a>
            <a href="car.php">سەبەتە</a>
        </div>

        <div class="box">
            <p > <b> پەیوەندییمان پێوە بکە</b></p>
            <p> <i class="fas fa-phone"></i> 0750 467 8998  </p>
            <p> <i class="fas fa-phone"></i> 0781 4677 8778 </p>
            <p> <i class="fas fa-envelope"></i> newarflowerstore@gmail.com </p>
            <p> <i class="fas fa-map-marker-alt"></i> Erbil, Kurdistan </p>
        </div>

        <div class="box">
               <p> <b>ئێمە لە تۆڕە کۆمەڵایەتییەکان</b></p>
        <a href="#"> <i class="fab fa-facebook-f"></i>Facebook</a>
        <a href="#"> <i class="fab fa-twitter"></i>Twiiter</a>
       <a href="#"> <i class="fab fa-instagram"></i>Instagram</a>
       <a href="#"><i class="fab fa-linkedin"></i>Linkedin</a>
</div>

    </div>

 

</section>